import { render } from '@testing-library/react';
import App from '.';

test('renders without crashing', () => {
  render(<App />);
});
